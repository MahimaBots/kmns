
<!DOCTYPE html>
<html>
 
<head>
    <title>Insert Page page</title>
</head>
 
<body>
    <center>
        <?php
 
        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        $conn = mysqli_connect("localhost", "root", "", "kmnsregister");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         
        // Taking all 5 values from the form data(input)
        $name =  $_REQUEST['name'];
        $id = $_REQUEST['id'];
        $email =  $_REQUEST['email'];
        $password = $_REQUEST['password'];
        $number = $_REQUEST['number'];
        $adress = $_REQUEST['adress'];
         
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO register  VALUES ('$name',
            '$id','$email','$password','$number','$adress')";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>Entered successfully. You will receive what you need in your email address within 24 hours.</h3>";
 
            // echo nl2br("\n$ip\n $user_name\n "
            //     . "$password\n $name\n $email");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
         
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
</body>
 
</html>