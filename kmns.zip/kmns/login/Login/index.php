<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create an Acount</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="box">
        <h3>Create an Acount</h3>
        
        <form action="inser.php" method="post">
            <div class="form">
                <input class="input" type="text" name="name" id="name" placeholder="UserName" required> <br><br>
                <input class="input" type="id" name="id" id="id" placeholder="Student Id" required> <br><br>
                <input class="input" type="email" name="email" id="email" placeholder="Email Adress" required> <br><br>
                <input class="input" type="password" name="password" id="password" placeholder="Password" required><br><br>
                <input class="input" type="number" name="number" id="number" placeholder="Phone Number" required><br><br>
                <input class="input" type="text" name="adress" id="adress" placeholder="Adress" required><br><br>
            </div>
        
        <center>
            <input  type="submit" value="Create" class="submit">
        </a>
        </center>
    </form>
        <br><br> 
    <h4> Alrady Registerd? &nbsp;&nbsp; <a class="login" href="login.php"> Login  </a> </h4>
    </div>
</body>
</html>