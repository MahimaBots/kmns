<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="box">
        <h3>Login</h3>
        
        <form action="inser.php">
            <div class="form">
                <input class="input" type="text" name="name" id="name" placeholder="UserName" required> <br><br>
                <input class="input" type="password" name="password" id="password" placeholder="Password" required><br><br>
            </div>
        
        <center>
            <input  type="submit" value="Login" class="submit">
        </a>
        </center>
    </form>
        <br><br> 
    <h4> Not Registerd? &nbsp;&nbsp; <a class="login" href="index.php"> Register  </a> </h4>
    </div>
</body>
</html>